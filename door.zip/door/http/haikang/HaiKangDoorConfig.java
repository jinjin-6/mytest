package com.bro.binterface.door.http.haikang;

import lombok.Data;

@Data
public class HaiKangDoorConfig {
    private String userName;
    private String passwd;
}
