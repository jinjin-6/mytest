package com.bro.binterface.door.http.haikang.utils;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethodBase;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.httpclient.methods.multipart.MultipartRequestEntity;
import org.apache.commons.httpclient.methods.multipart.Part;
import org.apache.commons.httpclient.methods.multipart.StringPart;

import java.io.File;
import java.io.IOException;

/**
 * HTTP请求工具类
 */
public class HttpHelper {
    /**
     * 普通的post请求，交互类型是json文本
     * 异常这里直接抛出，统一由调用方处理
     * 
     * @param url     URL
     * @param content 内容
     * @return
     * @throws Exception
     */
    public static HttpMethodBase post(String url, String content) throws Exception {
        PostMethod method = new PostMethod(url);
        method.setDoAuthentication(true);
        method.setRequestHeader("Content-Type", "application/json");
        method.setRequestEntity(new StringRequestEntity(content, "application/json", "UTF-8"));
        return method;
    }

    //
    /**
     * form表单形式的post请求，用于上传人脸图片
     * 
     * @param url       URL
     * @param content   JSON内容
     * @param faceImage 图像文件对象
     * @return
     * @throws Exception
     */
    public static HttpMethodBase postForm(String url, String content, File faceImage) throws Exception {
        // 创建表单参数
        Part[] parts = {
                new StringPart("FaceDataRecord", content, "application/json"),
                new FilePart("FaceImage", faceImage, "image/jpeg", "utf-8")
        };
        PostMethod method = new PostMethod(url);
        method.setRequestEntity(new MultipartRequestEntity(parts, method.getParams()));
        return method;
    }

    /**
     * 普通的put请求，交互类型是json文本
     * 异常这里直接抛出，统一由调用方处理
     * 
     * @param url     URL
     * @param content JSON格式内容串
     * @return
     */
    public static HttpMethodBase put(String url, String content) throws Exception {
        return put(url, content, "application/json");
    }

    /**
     * PUT方法
     * 
     * @param url         URL
     * @param content     内容：JSON/XML
     * @param contentType 内容类型
     * @return
     * @throws Exception
     */
    public static HttpMethodBase put(String url, String content, String contentType) throws Exception {
        PutMethod method = new PutMethod(url);
        method.setDoAuthentication(true);
        method.setRequestHeader("Content-Type", contentType);
        method.setRequestEntity(new StringRequestEntity(content, contentType, "UTF-8"));
        return method;
    }

    /**
     * GET方法
     * 
     * @param url
     * @return
     * @throws Exception
     */
    public static HttpMethodBase get(String url) throws Exception {
        GetMethod method = new GetMethod(url);
        method.setDoAuthentication(true);
        method.setRequestHeader("Content-Type", "application/json");
        return method;
    }

    /**
     * 通用部分封装
     * 
     * @param userName 用户名
     * @param password 密码
     * @param method   使用的方法对象
     * @return
     * @throws IOException
     */
    public static byte[] request(String userName, String password, HttpMethodBase method) throws IOException {
        HttpClient client = new HttpClient();
        UsernamePasswordCredentials creds = new UsernamePasswordCredentials(userName, password);
        client.getState().setCredentials(AuthScope.ANY, creds);
        client.executeMethod(method);
        byte[] responseData = method.getResponseBodyAsString().getBytes(method.getResponseCharSet());
        method.releaseConnection();
        return responseData;
    }
}
