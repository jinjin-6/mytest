package com.bro.binterface.door.http.haikang;

import com.alibaba.nacos.shaded.com.google.gson.Gson;
import com.bro.binterface.door.AccessDoor;
import com.bro.binterface.door.CmdParam;
import com.bro.binterface.door.http.haikang.cmd.HaiKangCmdHandleManager;
import com.bro.binterface.door.http.haikang.cmd.HaiKangCmdHandler;
import com.bro.binterface.door.http.haikang.thred.FetchEventThread;
import com.bro.binterface.door.http.haikang.utils.HttpHelper;
import com.bro.common.core.domain.R;
import com.bro.common.fsu.domain.vo.DeviceDoor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.httpclient.HttpMethodBase;
import org.springframework.stereotype.Component;

import java.util.Objects;

/**
 * 海康门禁 ISAPI
 */
@Slf4j
@Component
@Data
public class HaiKangAccessDoor extends DeviceDoor implements AccessDoor {
    private HaiKangDoorConfig config;

    public HaiKangAccessDoor(DeviceDoor door) {
        Objects.requireNonNull(door, "DeviceDoor不能为null");
        org.springframework.beans.BeanUtils.copyProperties(door, this);
        if (door.getCollectParam() != null) {
            try {
                this.config = new Gson().fromJson(door.getCollectParam(), HaiKangDoorConfig.class);
            } catch (Exception e) {
                log.error("解析collectParam失败: 门禁id[{}] 采集参数[{}]",
                        getFsuIdAndDeviceId() + door.getCollectParam(),
                        e);
                this.config = new HaiKangDoorConfig(); // 默认配置
            }
        }
    }

    @Override
    public void init() throws Exception {
        new Thread(new FetchEventThread(this)).start();
    }

    public R sendRequestWithResponse(HttpMethodBase method) {
        try {
            byte[] response = HttpHelper.request(config.getUserName(), config.getPasswd(), method);
            return R.ok(response);
        } catch (Exception ex) {
            return R.fail(ex.getMessage());
        }
    }

    @Override
    public void dispose() {

    }

    @Override
    public String getFsuIdAndDeviceId() {
        return super.getFsuId() + ":" + super.getDeviceId();
    }

    @Override
    public boolean isConnected() {
        return true;
    }

    @Override
    public R execCmd(CmdParam param) {
        HaiKangCmdHandler cmdHandler = HaiKangCmdHandleManager.getHandler(param.getCmd());
        if (cmdHandler != null) {
            return cmdHandler.exec(this, param);
        }
        return R.fail("命令不存在");
    }
}
