package com.bro.binterface.door.http.haikang.constants;

public class DoorEventCode {
    public final static int DOOR_EVENT_MAJOR = 0x05;// 门事件（主类型）
    public final static int DOOR_EVENT_MINOR_DOOR_OPENED = 0x15; //门打开（门锁）
    public final static int DOOR_EVENT_MINOR_DOOR_CLOSED = 0x16; // 门关闭（门锁）
    public final static int DOOR_EVENT_MINOR_FACE_AUTH_SUCCESS = 0x4B;// 人脸认证成功
    public final static int DOOR_EVENT_MINOR_FACE_AUTH_FAILED = 0x4C;// 人脸认证失败
}
