package com.bro.binterface.door.http.haikang.thred;

import com.bro.binterface.door.CmdParam;
import com.bro.binterface.door.http.haikang.HaiKangAccessDoor;
import com.bro.binterface.door.http.haikang.constants.DoorEventCode;
import com.bro.common.core.constant.Constants;
import com.bro.common.core.constant.DoorAccessDeviceCmdCode;
import com.bro.common.core.domain.R;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Data
@Slf4j
// @Component
public class FetchEventThread implements Runnable {

    private HaiKangAccessDoor device;

    /**
     * 构造函数
     * 
     * @param device
     */
    public FetchEventThread(HaiKangAccessDoor device) {
        this.device = device;
    }

    @Override
    public void run() {

        // 设置线程名称
        Thread.currentThread().setName("FetchEvent");

        // 日期格式化器
        DateTimeFormatter formatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME;

        // 时区（东八区）
        ZoneId zone = ZoneId.of("Asia/Shanghai");

        // 获取事件标记
        boolean fetchFlag = true;

        // 循环获取事件
        while (true) {
            ZonedDateTime now = ZonedDateTime.now(zone).truncatedTo(ChronoUnit.SECONDS);
            int second = now.getSecond();
            if (second == 0 && fetchFlag) {

                // 获取事件
                ZonedDateTime startZonedDateTime = now.minusMinutes(1);
                ZonedDateTime endZonedDateTime = startZonedDateTime.plusSeconds(59);
                String startTime = startZonedDateTime.format(formatter);
                String endTime = endZonedDateTime.format(formatter);
                featchEvents(startTime, endTime);

                fetchFlag = false;
            } else if (second != 0) {
                fetchFlag = true;
            }
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
            }
        }
    }

    /**
     * 获取指定时间段的事件
     * 
     * @param startTime: 开始时间
     * @param endTime:   结束时间
     */
    private void featchEvents(String startTime, String endTime) {

        // 获取事件条数
        int totalNum = getEventTotalNum(startTime, endTime);

        // 搜索ID
        UUID searchID = UUID.randomUUID();

        // 构造参数
        Map<String, Object> params = new HashMap<>();
        params.put("startTime", startTime);
        params.put("endTime", endTime);
        params.put("major", DoorEventCode.DOOR_EVENT_MAJOR);
        params.put("minor", DoorEventCode.DOOR_EVENT_MINOR_FACE_AUTH_SUCCESS);
        params.put("searchID", searchID);
        params.put("maxResults", 30);

        /**
         * 执行事件查询，每次请求最多30条记录，如果记录超过30条
         * 则执行多次查询，且要更新searchResultPosition，并且
         * 查询的searchID不能改变
         */
        for (int i = 0; i < totalNum / 30; ++i) {
            params.put("searchResultPosition", 30 * i);
            execHandle(DoorAccessDeviceCmdCode.HK_HTTP_EVENT_SEARCH, params);
        }

        // 查询零头，即不足30的部分
        if (totalNum % 30 > 0) {
            params.put("searchResultPosition", 30 * (totalNum / 30));
            execHandle(DoorAccessDeviceCmdCode.HK_HTTP_EVENT_SEARCH, params);
        }
    }

    /**
     * 获取指定时间段的事件条数
     * 
     * @param startTime: 开始时间
     * @param endTime:   结束时间
     * @return
     */
    private int getEventTotalNum(String startTime, String endTime) {

        // 构造参数
        Map<String, Object> params = new HashMap<>();
        params.put("startTime", startTime);
        params.put("endTime", endTime);
        params.put("major", DoorEventCode.DOOR_EVENT_MAJOR);
        params.put("minor", DoorEventCode.DOOR_EVENT_MINOR_FACE_AUTH_SUCCESS);

        // 执行请求
        String jsonString = execHandle(DoorAccessDeviceCmdCode.HK_HTTP_EVENT_COUNT_SEARCH, params);

        // 解析长度
        JSONObject jsonObject = new JSONObject(jsonString);
        JSONObject acsEventTotalNum = jsonObject.getJSONObject("AcsEventTotalNum");
        return acsEventTotalNum.getInt("totalNum");
    }

    /**
     * 执行命令函数封装
     * 
     * @param cmdCode: 命令码
     * @param params:  参数
     * @return
     */
    public String execHandle(String cmdCode, Map<String, Object> params) {
        CmdParam cmdParam = new CmdParam();
        cmdParam.setCmd(cmdCode);
        cmdParam.setParams(params);
        R ret = device.execCmd(cmdParam);
        if (ret.getCode() == Constants.SUCCESS) {
            try {
                String strResponseData = new String((byte[]) ret.getData(), "utf-8");
                log.debug("receive http ：{}",strResponseData);
                return strResponseData;
            } catch (UnsupportedEncodingException e) {
                return "";
            }
        } else {
            log.warn("封装命令函数失败：{}",ret.getMsg());
            return ret.getMsg();
        }
    }
}
