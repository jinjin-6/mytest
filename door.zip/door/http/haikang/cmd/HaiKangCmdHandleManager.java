package com.bro.binterface.door.http.haikang.cmd;

import java.util.HashMap;
import java.util.Map;

public final class HaiKangCmdHandleManager {
    private static Map<String, HaiKangCmdHandler> handlers = new HashMap<>();

    public static void register(String cmdCode, HaiKangCmdHandler handler) {
        handlers.put(cmdCode, handler);
    }

    public static HaiKangCmdHandler getHandler(String cmdCode) {
        return handlers.get(cmdCode);
    }
}
