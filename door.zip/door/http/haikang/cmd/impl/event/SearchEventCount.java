package com.bro.binterface.door.http.haikang.cmd.impl.event;

import com.bro.binterface.door.CmdParam;
import com.bro.binterface.door.http.haikang.HaiKangAccessDoor;
import com.bro.binterface.door.http.haikang.cmd.HaiKangCmdHandleManager;
import com.bro.binterface.door.http.haikang.cmd.HaiKangCmdHandler;
import com.bro.binterface.door.http.haikang.utils.HttpHelper;
import com.bro.common.core.constant.DoorAccessDeviceCmdCode;
import com.bro.common.core.domain.R;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.httpclient.HttpMethodBase;
import org.json.JSONObject;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

/**
 * 搜索门禁事件条数
 * 参数：
 * startTime：搜索的开始时间
 * endTime：搜索的结束时间
 * 
 * 信息格式(JSON):
 * {
 * "AcsEventTotalNumCond": {
 * "major": 0,
 * "minor": 0,
 * "startTime": "2024-05-08T00:00:00+08:00",
 * "endTime": "2024-05-08T23:59:59+08:00"
 * }
 * }
 * 
 */
@Slf4j
@Component
public class SearchEventCount implements HaiKangCmdHandler, InitializingBean {

    private CmdParam param;

    @Override
    public void afterPropertiesSet() throws Exception {
        HaiKangCmdHandleManager.register(DoorAccessDeviceCmdCode.HK_HTTP_EVENT_COUNT_SEARCH, this);
    }

    public Object getParams(String key) {
        return param.getParams().get(key);
    }

    @Override
    public R exec(HaiKangAccessDoor device, CmdParam param) {
        this.param = param;

        // 获取参数
        int major = (int) getParams("major");
        int minor = (int) getParams("minor");
        String startTime = getParams("startTime").toString();
        String endTime = getParams("endTime").toString();

        // AcsEventTotalNumCond
        JSONObject acsEventTotalNumCond = new JSONObject();
        acsEventTotalNumCond.put("major", major);
        acsEventTotalNumCond.put("minor", minor);
        acsEventTotalNumCond.put("startTime", startTime);
        acsEventTotalNumCond.put("endTime", endTime);

        JSONObject jsonObj = new JSONObject();
        jsonObj.put("AcsEventTotalNumCond", acsEventTotalNumCond);

        HttpMethodBase method;

        try {
            String url = String.format("http://%s:%d/ISAPI/AccessControl/AcsEventTotalNum?format=json", device.getIp(),
                    device.getPort());
            method = HttpHelper.post(url, jsonObj.toString());
        } catch (Exception ex) {
            return R.fail(ex.getMessage());
        }

        return device.sendRequestWithResponse(method);
    }
}
