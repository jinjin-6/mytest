package com.bro.binterface.door.http.haikang.cmd.impl.door;

import com.bro.binterface.door.CmdParam;
import com.bro.binterface.door.http.haikang.HaiKangAccessDoor;
import com.bro.binterface.door.http.haikang.cmd.HaiKangCmdHandleManager;
import com.bro.binterface.door.http.haikang.cmd.HaiKangCmdHandler;
import com.bro.binterface.door.http.haikang.utils.HttpHelper;
import com.bro.common.core.constant.DoorAccessDeviceCmdCode;
import com.bro.common.core.domain.R;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.httpclient.HttpMethodBase;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

/**
 * 响应格式(JSON):
 * {
 * " AcsWorkStatus": {
 * " doorLockStatus": [0, 4],
 * " doorStatus": [4, 0],
 * " magneticStatus": [0, 0],
 * " antiSneakStatus": "close",
 * " hostAntiDismantleStatus": "close",
 * " cardReaderOnlineStatus": [1],
 * " cardReaderVerifyMode": [10, 10],
 * " cardNum": 1,
 * " netStatus": "connect",
 * " sipStatus": "unregistered",
 * " doorOnlineStatus": [1]
 * }
 * }
 * 
 * 1. "doorLockStatus": [1, 2, 1, 2],
 * 门锁状态（继电器开合状态）,[0#正常关,1#正常开,2#短路报警,3#断路报警,4#异常报警], desc:门锁状态（继电器开合状
 * 态），（[1,2,1,2]代表：门锁1正常开，门锁2短路报警，门锁3正常开，门锁4短路报警）
 * 2. "doorStatus": [1, 2, 1, 2],
 * 门状态（楼层状态）, subType:int, [1#休眠,2#常开状态（自由）,3#常闭状态（禁用）,4#普通状态（受控）], desc:门状态（楼层状
 * 态），1-休眠，2-常开状态（自由），3-常闭状态（禁用），4-普通状态（受控）（[1,2,1,2]代表：门1休眠，门2常开状态，门3休眠，门4常开状态）
 * 3. "magneticStatus": [1, 2, 1, 2],
 * 门磁状态, subType:int, [0#正常关,1#正常开,2#短路报警,3#断路报警,4#异常报警],
 * desc:门磁状态，0-正常关，1-正常开，2-短路报警，3-
 * 断路报警，4-异常报警（[1,2,1,2]代表：门磁1正常开，门磁2短路报警，门磁3正常开，门磁4短路报警）
 */
@Slf4j
@Component
public class GetAccessControlWorkStatus implements HaiKangCmdHandler, InitializingBean {

    @Override
    public void afterPropertiesSet() throws Exception {
        HaiKangCmdHandleManager.register(DoorAccessDeviceCmdCode.HK_HTTP_ACCESS_CONTROL_WORK_STATUS, this);
    }

    @Override
    public R exec(HaiKangAccessDoor device, CmdParam param) {
        HttpMethodBase method;

        try {
            String url = String.format("http://%s:%d/ISAPI/AccessControl/AcsWorkStatus?format=json", device.getIp(),
                    device.getPort());
            method = HttpHelper.get(url);
        } catch (Exception ex) {
            return R.fail(ex.getMessage());
        }

        return device.sendRequestWithResponse(method);
    }
}
