package com.bro.binterface.door.http.haikang.cmd.impl.door;

import com.bro.binterface.door.CmdParam;
import com.bro.binterface.door.http.haikang.HaiKangAccessDoor;
import com.bro.binterface.door.http.haikang.cmd.HaiKangCmdHandleManager;
import com.bro.binterface.door.http.haikang.cmd.HaiKangCmdHandler;
import com.bro.binterface.door.http.haikang.utils.HttpHelper;
import com.bro.common.core.constant.Constants;
import com.bro.common.core.constant.DoorAccessDeviceCmdCode;
import com.bro.common.core.domain.R;
import lombok.extern.slf4j.Slf4j;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMXMLBuilderFactory;
import org.apache.commons.httpclient.HttpMethodBase;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import javax.xml.namespace.QName;
import java.io.ByteArrayInputStream;

/**
 * 开/关门
 * 协议内容：
 * -参数：doorNo 门编号，65535代表所有门
 * -参数：open#开门,close#关门
 */
@Slf4j
@Component
public class RemoteControl implements HaiKangCmdHandler, InitializingBean {

    private CmdParam param;

    @Override
    public void afterPropertiesSet() throws Exception {
        HaiKangCmdHandleManager.register(DoorAccessDeviceCmdCode.HK_HTTP_DOOR_CONTROL, this);
    }

    public Object getParams(String key) {
        return param.getParams().get(key);
    }

    @Override
    public R exec(HaiKangAccessDoor device, CmdParam param) {
        this.param = param;
        // 获取参数
        if (getParams("doorNum") == null) {
            return R.fail("缺少参数doorNum");
        }
        int doorNo = (int) getParams("doorNum");
        if (getParams("doorOperation") == null) {
            return R.fail("缺少参数doorOperation");
        }
        int op = (int) getParams("doorOperation");
        // 0开门 1关门
        String opt = "open";
        if (op == 1) {
            opt = "close";
        }

        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<RemoteControlDoor xmlns=\"http://www.isapi.org/ver20/XMLSchema\" version=\"2.0\">"
                + String.format("<cmd>%s</cmd>", opt)
                + "</RemoteControlDoor>";

        HttpMethodBase method;

        try {
            String url = String.format("http://%s:%d/ISAPI/AccessControl/RemoteControl/door/%d", device.getIp(),
                    device.getPort(), doorNo);
            method = HttpHelper.put(url, xml, "application/xml");
            R ret = device.sendRequestWithResponse(method);
            if (ret.getCode() == Constants.FAIL) {
                return ret;
            }
            byte[] data = (byte[]) ret.getData();
            // 解析响应xml数据
            OMElement root = OMXMLBuilderFactory.createOMBuilder(new ByteArrayInputStream(data)).getDocumentElement();
            OMElement elem = root.getFirstChildWithName(new QName("statusCode"));
            String resp = elem.getText();
            if ("0".equals(resp) || "1".equals(resp)) {
                return R.ok("操作成功");
            } else {
                return R.fail("操作失败");
            }
        } catch (Exception ex) {
            return R.fail(ex.getMessage());
        }

    }
}
