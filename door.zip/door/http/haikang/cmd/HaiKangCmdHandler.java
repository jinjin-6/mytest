package com.bro.binterface.door.http.haikang.cmd;

import com.bro.binterface.door.CmdParam;
import com.bro.binterface.door.http.haikang.HaiKangAccessDoor;
import com.bro.common.core.domain.R;

/**
 * 命令接口
 */
public interface HaiKangCmdHandler {

    /**
     * 命令执行
     * 
     * @param param
     */
    R exec(HaiKangAccessDoor device, CmdParam param);
}
