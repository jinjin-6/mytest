package com.bro.binterface.door.tcp.gaoyou.message;

public class GaoYouDoorRecordInfo {
    public int recType;
    public int recIndex;
    public int loopFlag;
}
