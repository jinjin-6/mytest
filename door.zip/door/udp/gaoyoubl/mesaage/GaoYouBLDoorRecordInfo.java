package com.bro.binterface.door.udp.gaoyoubl.mesaage;

public class GaoYouBLDoorRecordInfo {
    public int recType;
    public int recIndex;
    public int loopFlag;
}
